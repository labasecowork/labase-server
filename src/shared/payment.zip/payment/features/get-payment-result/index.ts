export { resultRoutes } from "./presentation/get-payment-result.routes";
